Units with the <code>AIRSTAGINGPLATFORM</code> category.
<table>
    <tr>
        <td><a href="ARMCARRY"><img src="icons/units/ARMCARRY_icon.png" width="21px" /></a></td>
        <td><code>armcarry</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMCARRY">Colossus: Tech 2 Light Carrier</a></td>
    </tr>
    <tr>
        <td><a href="CORCARRY"><img src="icons/units/CORCARRY_icon.png" width="21px" /></a></td>
        <td><code>corcarry</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORCARRY">Hive: Tech 2 Light Carrier</a></td>
    </tr>
    <tr>
        <td><a href="ARMASP"><img src="icons/units/ARMASP_icon.png" width="21px" /></a></td>
        <td><code>armasp</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMASP">Air Repair Pad: Tech 3 Automatically repairs aircraft</a></td>
    </tr>
    <tr>
        <td><a href="CORASP"><img src="icons/units/CORASP_icon.png" width="21px" /></a></td>
        <td><code>corasp</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORASP">Air Repair Pad: Tech 3 Automatically repairs aircraft</a></td>
    </tr>
</table>
