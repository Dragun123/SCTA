Units with the <code>HOVER</code> category.
<table>
    <tr>
        <td><a href="ARMAMPH"><img src="icons/units/ARMAMPH_icon.png" width="21px" /></a></td>
        <td><code>armamph</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMAMPH">Pelican: Tech 2 Amphibious Kbot</a></td>
    </tr>
    <tr>
        <td><a href="CORAMPH"><img src="icons/units/CORAMPH_icon.png" width="21px" /></a></td>
        <td><code>coramph</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORAMPH">Gimp: Tech 2 Amphibious Kbot</a></td>
    </tr>
    <tr>
        <td><a href="ARMAH"><img src="icons/units/ARMAH_icon.png" width="21px" /></a></td>
        <td><code>armah</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMAH">Swatter: Tech 3 Anti-Air Hovercraft</a></td>
    </tr>
    <tr>
        <td><a href="ARMANAC"><img src="icons/units/ARMANAC_icon.png" width="21px" /></a></td>
        <td><code>armanac</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMANAC">Anaconda: Tech 3 Hovertank</a></td>
    </tr>
    <tr>
        <td><a href="ARMCH"><img src="icons/units/ARMCH_icon.png" width="21px" /></a></td>
        <td><code>armch</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMCH">Construction Hovercraft: Tech 3 Tech Level 3</a></td>
    </tr>
    <tr>
        <td><a href="ARMMH"><img src="icons/units/ARMMH_icon.png" width="21px" /></a></td>
        <td><code>armmh</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMMH">Wombat: Tech 3 Hovercraft Rocket Launcher</a></td>
    </tr>
    <tr>
        <td><a href="ARMSH"><img src="icons/units/ARMSH_icon.png" width="21px" /></a></td>
        <td><code>armsh</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSH">Skimmer: Tech 3 Scout Hovercraft</a></td>
    </tr>
    <tr>
        <td><a href="ARMTHOVR"><img src="icons/units/ARMTHOVR_icon.png" width="21px" /></a></td>
        <td><code>armthovr</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMTHOVR">Bear: Tech 3 Hover Transport</a></td>
    </tr>
    <tr>
        <td><a href="CORAH"><img src="icons/units/CORAH_icon.png" width="21px" /></a></td>
        <td><code>corah</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORAH">Slinger: Tech 3 Anti-Air Hovercraft</a></td>
    </tr>
    <tr>
        <td><a href="CORCH"><img src="icons/units/CORCH_icon.png" width="21px" /></a></td>
        <td><code>corch</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORCH">Construction Hovercraft: Tech 3 Tech Level 3</a></td>
    </tr>
    <tr>
        <td><a href="CORMH"><img src="icons/units/CORMH_icon.png" width="21px" /></a></td>
        <td><code>cormh</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORMH">Nixer: Tech 3 Hovercraft Rocket Launcher</a></td>
    </tr>
    <tr>
        <td><a href="CORSH"><img src="icons/units/CORSH_icon.png" width="21px" /></a></td>
        <td><code>corsh</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSH">Scrubber: Tech 3 Scout Hovercraft</a></td>
    </tr>
    <tr>
        <td><a href="CORSNAP"><img src="icons/units/CORSNAP_icon.png" width="21px" /></a></td>
        <td><code>corsnap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSNAP">Snapper: Tech 3 Hovertank</a></td>
    </tr>
    <tr>
        <td><a href="CORTHOVR"><img src="icons/units/CORTHOVR_icon.png" width="21px" /></a></td>
        <td><code>corthovr</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORTHOVR">Turtle: Tech 3 Hover Transport</a></td>
    </tr>
</table>
