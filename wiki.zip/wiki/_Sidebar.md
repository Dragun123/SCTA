<brewwikisidebar>
<details markdown="1">
<summary>[Show] <a href="SCTATest">SCTATest</a></summary>
<p>
<table>
<tr>
<td width="269px">

<details>
<summary>ARM</summary>
<p>

* <a title="Vulcan" href="ARMVULC">Rapid Fire Plasma Cannon</a>
* <a title="Protector" href="ARMAMD">Tech 3 Anti Missile Defense System</a>
* <a title="Flakker" href="ARMFLAK">Tech 3 Anti-Air Flak Gun</a>
* <a title="Swatter" href="ARMAH">Tech 3 Anti-Air Hovercraft</a>
* <a title="Air Repair Pad" href="ARMASP">Tech 3 Automatically repairs aircraft</a>
* <a title="Seaplane Platform" href="ARMPLAT">Tech 3 Builds Seaplanes</a>
* <a title="Seaplane Platform" href="CORPLAT">Tech 3 Builds Seaplanes</a>
* <a title="Moho Metal Maker" href="ARMMMKR">Tech 3 Converts Energy into Metal</a>
* <a title="Annihilator" href="ARMANNI">Tech 3 Energy Weapon</a>
* <a title="Advanced Sonar Station" href="ARMASON">Tech 3 Extended Sonar</a>
* <a title="Bear" href="ARMTHOVR">Tech 3 Hover Transport</a>
* <a title="Wombat" href="ARMMH">Tech 3 Hovercraft Rocket Launcher</a>
* <a title="Anaconda" href="ARMANAC">Tech 3 Hovertank</a>
* <a title="Advanced Radar Tower" href="ARMARAD">Tech 3 Long Range Radar Tower</a>
* <a title="Retaliator" href="ARMSILO">Tech 3 Nuclear Missile Launcher</a>
* <a title="Ambusher" href="ARMAMB">Tech 3 Pop-up Heavy Cannon</a>
* <a title="Cloakable Fusion Reactor" href="ARMCKFUS">Tech 3 Produces Energy</a>
* <a title="Seahawk" href="ARMSEHAK">Tech 3 Radar Plane</a>
* <a title="Skimmer" href="ARMSH">Tech 3 Scout Hovercraft</a>
* <a title="Tornado" href="ARMSFIG">Tech 3 Seaplane Fighter</a>
* <a title="Construction Hovercraft" href="ARMCH">Tech 3 Tech Level 3</a>
* <a title="Construction Seaplane" href="ARMCSA">Tech 3 Tech Level 3</a>
* <a title="Albatross" href="ARMSEAP">Tech 3 Torpedo Bomber</a>
* <a title="Moho Mine" href="ARMMOHO">Tech 2 Advanced Metal Extractor</a>
* <a title="Advanced Torpedo Launcher" href="ARMATL">Tech 2 Advanced Torpedo Launcher</a>
* <a title="Pelican" href="ARMAMPH">Tech 2 Amphibious Kbot</a>
* <a title="Triton" href="ARMCROC">Tech 2 Amphibious Tank</a>
* <a title="Archer" href="ARMAAS">Tech 2 Anti-Air Ship</a>
* <a title="Zeus" href="ARMZEUS">Tech 2 Assault Kbot</a>
* <a title="Millennium" href="ARMBATS">Tech 2 Battleship</a>
* <a title="Hovercraft Platform" href="ARMHP">Tech 2 Builds Hovercraft</a>
* <a title="Commander" href="ARMDECOM">Tech 2 Commander</a>
* <a title="Invader" href="ARMVADER">Tech 2 Crawling Bomb</a>
* <a title="Conqueror" href="ARMCRUS">Tech 2 Cruiser</a>
* <a title="Stunner" href="ARMEMP">Tech 2 EMP Missile Launcher</a>
* <a title="FARK" href="ARMFARK">Tech 2 Fast Assist-Repair Kbot</a>
* <a title="Zipper" href="ARMFAST">Tech 2 Fast Attack Kbot</a>
* <a title="Brawler" href="ARMBRAWL">Tech 2 Gunship</a>
* <a title="Maverick" href="ARMMAV">Tech 2 Gunslinger Kbot</a>
* <a title="Bulldog" href="ARMBULL">Tech 2 Heavy Assault Tank</a>
* <a title="Sentinel" href="ARMHLT">Tech 2 Heavy Laser Tower</a>
* <a title="Precision Mine" href="MINE4">Tech 2 High Damage, Small Range Mine</a>
* <a title="Colossus" href="ARMCARRY">Tech 2 Light Carrier</a>
* <a title="Panther" href="ARMLATNK">Tech 2 Lightning Tank</a>
* <a title="Tiny" href="MINE1">Tech 2 Low Damage, Med. Range Mine</a>
* <a title="Scarab" href="ARMSCAB">Tech 2 Missile Defense</a>
* <a title="Ranger" href="ARMMSHIP">Tech 2 Missile Ship</a>
* <a title="Luger" href="ARMMART">Tech 2 Mobile Artillery</a>
* <a title="Penetrator" href="ARMMANNI">Tech 2 Mobile Energy Weapon</a>
* <a title="Phalanx" href="ARMYORK">Tech 2 Mobile Flak Vehicle</a>
* <a title="Jammer" href="ARMJAM">Tech 2 Mobile Radar Jammer</a>
* <a title="Escort" href="ARMSJAM">Tech 2 Mobile Radar Jammer</a>
* <a title="Marky" href="ARMMARK">Tech 2 Mobile Radar Kbot</a>
* <a title="Seer" href="ARMSEER">Tech 2 Mobile Radar</a>
* <a title="Merl" href="ARMMERL">Tech 2 Mobile Rocket Launcher</a>
* <a title="Guardian" href="ARMGUARD">Tech 2 Plasma Battery</a>
* <a title="Adv. Aircraft Plant" href="ARMAAP">Tech 2 Produces Aircraft</a>
* <a title="Fusion Reactor" href="ARMFUS">Tech 2 Produces Energy</a>
* <a title="Adv. Kbot Lab" href="ARMALAB">Tech 2 Produces Kbots</a>
* <a title="Adv. Shipyard" href="ARMASY">Tech 2 Produces Ships</a>
* <a title="Adv. Vehicle Plant" href="ARMAVP">Tech 2 Produces Vehicles</a>
* <a title="Eraser" href="ARMASER">Tech 2 Radar Jammer</a>
* <a title="Eagle" href="ARMAWAC">Tech 2 Radar Plane</a>
* <a title="Fido" href="ARMFIDO">Tech 2 Skirmish Kbot</a>
* <a title="Shooter" href="ARMSNIPE">Tech 2 Sniper Kbot</a>
* <a title="Spider" href="ARMSPID">Tech 2 Spider Assault Vehicle</a>
* <a title="Infiltrator" href="ARMSPY">Tech 2 Spybot Kbot</a>
* <a title="Hawk" href="ARMHAWK">Tech 2 Stealth Fighter</a>
* <a title="Pheonix" href="ARMPNIX">Tech 2 Strategic Bomber</a>
* <a title="Pirahna" href="ARMSUBK">Tech 2 Submarine Killer </a>
* <a title="Fibber" href="ARMSCRAM">Tech 2 Submersible Mobile Radar Jammer</a>
* <a title="Adv. Construction Aircraft" href="ARMACA">Tech 2 Tech Level 2</a>
* <a title="Adv. Construction Kbot" href="ARMACK">Tech 2 Tech Level 2</a>
* <a title="Advanced Construction Sub" href="ARMACSUB">Tech 2 Tech Level 2</a>
* <a title="Adv. Construction Vehicle" href="ARMACV">Tech 2 Tech Level 2</a>
* <a title="Lancet" href="ARMLANCE">Tech 2 Torpedo Bomber</a>
* <a title="Peeper" href="ARMPEEP">Tech 1 Air Scout</a>
* <a title="Atlas" href="ARMATLAS">Tech 1 Air Transport</a>
* <a title="Jethro" href="ARMJETH">Tech 1 Anti-Air Kbot</a>
* <a title="Hammer" href="ARMHAM">Tech 1 Artillery Kbot</a>
* <a title="Thunder" href="ARMTHUND">Tech 1 Bomber</a>
* <a title="Metal Maker" href="ARMMAKR">Tech 1 Converts Energy into Metal</a>
* <a title="Crusader" href="ARMROY">Tech 1 Destroyer</a>
* <a title="Metal Extractor" href="ARMMEX">Tech 1 Extracts Metal</a>
* <a title="Flash" href="ARMFLASH">Tech 1 Fast Assault Tank</a>
* <a title="Jeffy" href="ARMFAV">Tech 1 Fast Attack Vehicle</a>
* <a title="Flea" href="ARMFLEA">Tech 1 Fast Light Scout Kbot</a>
* <a title="Freedom Fighter" href="ARMFIG">Tech 1 Fighter</a>
* <a title="Energy Storage" href="ARMESTOR">Tech 1 Increases Energy Storage</a>
* <a title="Metal Storage" href="ARMMSTOR">Tech 1 Increases Metal Storage</a>
* <a title="Peewee" href="ARMPW">Tech 1 Infantry Kbot</a>
* <a title="Sonar Station" href="ARMSONAR">Tech 1 Locates Water Units</a>
* <a title="Stumpy" href="ARMSTUMP">Tech 1 Medium Assault Tank</a>
* <a title="Warrior" href="ARMWAR">Tech 1 Medium Infantry Kbot</a>
* <a title="Podger" href="ARMMLV">Tech 1 Mine Layer Vehicle</a>
* <a title="Defender" href="ARMRL">Tech 1 Missile Tower</a>
* <a title="Samson" href="ARMSAM">Tech 1 Mobile SAM Launcher</a>
* <a title="Dragons Teeth" href="ARMDRAG">Tech 1 Perimeter Defence</a>
* <a title="Aircraft Plant" href="ARMAP">Tech 1 Produces Aircraft</a>
* <a title="Geothermal Powerplant" href="ARMGEO">Tech 1 Produces Energy</a>
* <a title="Tidal Generator" href="ARMTIDE">Tech 1 Produces Energy</a>
* <a title="Kbot Lab" href="ARMLAB">Tech 1 Produces Kbots</a>
* <a title="Shipyard" href="ARMSY">Tech 1 Produces Ships</a>
* <a title="Vehicle Plant" href="ARMVP">Tech 1 Produces Vehicles</a>
* <a title="Radar Tower" href="ARMRAD">Tech 1 Radar Tower</a>
* <a title="Rocko" href="ARMROCK">Tech 1 Rocket Kbot</a>
* <a title="Skeeter" href="ARMPT">Tech 1 Scout Ship</a>
* <a title="Lurker" href="ARMSUB">Tech 1 Submarine</a>
* <a title="Construction Aircraft" href="ARMCA">Tech 1 Tech Level 1</a>
* <a title="Construction Kbot" href="ARMCK">Tech 1 Tech Level 1</a>
* <a title="Construction Ship" href="ARMCS">Tech 1 Tech Level 1</a>
* <a title="Construction Vehicle" href="ARMCV">Tech 1 Tech Level 1</a>
* <a title="Torpedo Launcher" href="ARMTL">Tech 1 Torpedo Launcher</a>
* <a title="Commander" href="ARMCOM">Commander</a>
</p>
</details>
<details>
<summary>CORE</summary>
<p>

* <a title="Krogoth Gantry" href="CORGANT">Builds Krogoths</a>
* <a title="Krogoth" href="CORKROG">Experimental Kbot</a>
* <a title="Buzzsaw" href="CORBUZZ">Rapid Fire Plasma Cannon</a>
* <a title="Fortitude Missile Defense" href="CORFMD">Tech 3 Anti Missile Defense System</a>
* <a title="Cobra" href="CORFLAK">Tech 3 Anti-Air Flak Gun</a>
* <a title="Slinger" href="CORAH">Tech 3 Anti-Air Hovercraft</a>
* <a title="Air Repair Pad" href="CORASP">Tech 3 Automatically repairs aircraft</a>
* <a title="Moho Metal Maker" href="CORMMKR">Tech 3 Converts Energy into Metal</a>
* <a title="Doomsday Machine" href="CORDOOM">Tech 3 Energy Weapon</a>
* <a title="Advanced Sonar Station" href="CORASON">Tech 3 Extended Sonar</a>
* <a title="Turtle" href="CORTHOVR">Tech 3 Hover Transport</a>
* <a title="Nixer" href="CORMH">Tech 3 Hovercraft Rocket Launcher</a>
* <a title="Snapper" href="CORSNAP">Tech 3 Hovertank</a>
* <a title="Intimidator" href="CORINT">Tech 3 Long Range Plasma Cannon</a>
* <a title="Advanced Radar Tower" href="CORARAD">Tech 3 Long Range Radar Tower</a>
* <a title="Silencer" href="CORSILO">Tech 3 Nuclear Missile Launcher</a>
* <a title="Toaster" href="CORTOAST">Tech 3 Pop-up Heavy Cannon</a>
* <a title="Cloakable Fusion Reactor" href="CORCKFUS">Tech 3 Produces Energy</a>
* <a title="Hunter" href="CORHUNT">Tech 3 Radar Plane</a>
* <a title="Scrubber" href="CORSH">Tech 3 Scout Hovercraft</a>
* <a title="Voodoo" href="CORSFIG">Tech 3 Seaplane Fighter</a>
* <a title="Construction Hovercraft" href="CORCH">Tech 3 Tech Level 3</a>
* <a title="Construction Seaplane" href="CORCSA">Tech 3 Tech Level 3</a>
* <a title="Typhoon" href="CORSEAP">Tech 3 Torpedo Bomber</a>
* <a title="Moho Mine" href="CORMOHO">Tech 2 Advanced Metal Extractor</a>
* <a title="Advanced Torpedo Launcher" href="CORATL">Tech 2 Advanced Torpedo Launcher</a>
* <a title="Gimp" href="CORAMPH">Tech 2 Amphibious Kbot</a>
* <a title="Crock" href="CORSEAL">Tech 2 Amphibious Tank</a>
* <a title="Shredder" href="CORARCH">Tech 2 Anti-Air Ship</a>
* <a title="The Can" href="CORCAN">Tech 2 Armored Assault Kbot</a>
* <a title="Sumo" href="CORSUMO">Tech 2 Armored Assault Kbot</a>
* <a title="Pyro" href="CORPYRO">Tech 2 Assault Kbot</a>
* <a title="Leviathen" href="CORSSUB">Tech 2 Battle Submarine</a>
* <a title="Warlord" href="CORBATS">Tech 2 Battleship</a>
* <a title="Hovercraft Platform" href="CORHP">Tech 2 Builds Hovercraft</a>
* <a title="Commander" href="CORDECOM">Tech 2 Commander</a>
* <a title="Roach" href="CORROACH">Tech 2 Crawling Bomb</a>
* <a title="Executioner" href="CORCRUS">Tech 2 Cruiser</a>
* <a title="Freaker" href="CORFAST">Tech 2 Fast Attack Kbot</a>
* <a title="Rapier" href="CORAPE">Tech 2 Gunship</a>
* <a title="Reaper" href="CORREAP">Tech 2 Heavy Assault Tank</a>
* <a title="Thunderbolt" href="CORFHLT">Tech 2 Heavy Laser Tower</a>
* <a title="Hive" href="CORCARRY">Tech 2 Light Carrier</a>
* <a title="Focused Mine" href="MINE3">Tech 2 Med. Damage, Medium Range Mine</a>
* <a title="Area Mine" href="MINE2">Tech 2 Medium Damage, Small Range Mine</a>
* <a title="Hedgehog" href="CORMABM">Tech 2 Missile Defense</a>
* <a title="Hydra" href="CORMSHIP">Tech 2 Missile Ship</a>
* <a title="Pillager" href="CORMART">Tech 2 Mobile Artillery</a>
* <a title="Copperhead" href="CORSENT">Tech 2 Mobile Flak Vehicle</a>
* <a title="Morty" href="CORMORT">Tech 2 Mobile Mortar Kbot</a>
* <a title="Deleter" href="CORETER">Tech 2 Mobile Radar Jammer</a>
* <a title="Voyeur" href="CORVOYR">Tech 2 Mobile Radar Kbot</a>
* <a title="Deleter" href="CORSJAM">Tech 2 Mobile Radar Naval Jammer</a>
* <a title="Informer" href="CORVRAD">Tech 2 Mobile Radar</a>
* <a title="Dominator" href="CORHRK">Tech 2 Mobile Rocket Launcher</a>
* <a title="Diplomat" href="CORVROC">Tech 2 Mobile Rocket Launcher</a>
* <a title="Punisher" href="CORPUN">Tech 2 Plasma Battery</a>
* <a title="Viper" href="CORVIPE">Tech 2 Pop-up Laser Cannon</a>
* <a title="Adv. Aircraft Plant" href="CORAAP">Tech 2 Produces Aircraft</a>
* <a title="Fusion Power Plant" href="CORFUS">Tech 2 Produces Energy</a>
* <a title="Adv. Kbot Lab" href="CORALAB">Tech 2 Produces Kbots</a>
* <a title="Adv. Shipyard" href="CORASY">Tech 2 Produces Ships</a>
* <a title="Adv. Vehicle Plant" href="CORAVP">Tech 2 Produces Vehicles</a>
* <a title="Spectre" href="CORSPEC">Tech 2 Radar Jammer</a>
* <a title="Vulture" href="CORAWAC">Tech 2 Radar Plane</a>
* <a title="Necro" href="CORNECRO">Tech 2 Resurrection Kbot</a>
* <a title="Parasite" href="CORSPY">Tech 2 Spybot Kbot</a>
* <a title="Vamp" href="CORVAMP">Tech 2 Stealth Fighter</a>
* <a title="Hurricane" href="CORHURC">Tech 2 Strategic Bomber</a>
* <a title="Shark" href="CORSHARK">Tech 2 Submarine Killer </a>
* <a title="Neutron" href="CORTRON">Tech 2 Tactical Nuke Launcher</a>
* <a title="Adv. Construction Aircraft" href="CORACA">Tech 2 Tech Level 2</a>
* <a title="Construction Kbot" href="CORACK">Tech 2 Tech Level 2</a>
* <a title="Advanced Construction Sub" href="CORACSUB">Tech 2 Tech Level 2</a>
* <a title="Adv. Construction Vehicle" href="CORACV">Tech 2 Tech Level 2</a>
* <a title="Titan" href="CORTITAN">Tech 2 Torpedo Bomber</a>
* <a title="Goliath" href="CORGOL">Tech 2 Very Heavy Assault Tank</a>
* <a title="Fink" href="CORFINK">Tech 1 Air Scout</a>
* <a title="Valkyrie" href="CORVALK">Tech 1 Air Transport</a>
* <a title="Thud" href="CORTHUD">Tech 1 Artillery Kbot</a>
* <a title="Instigator" href="CORGATOR">Tech 1 Assault Tank</a>
* <a title="Shadow" href="CORSHAD">Tech 1 Bomber</a>
* <a title="Enforcer" href="CORROY">Tech 1 Destroyer</a>
* <a title="Metal Extractor" href="CORMEX">Tech 1 Extracts Metal</a>
* <a title="Avenger" href="CORVENG">Tech 1 Fighter</a>
* <a title="Energy Storage" href="CORESTOR">Tech 1 Increases Energy Storage</a>
* <a title="Metal Storage" href="CORMSTOR">Tech 1 Increases Metal Storage</a>
* <a title="A.K." href="CORAK">Tech 1 Infantry Kbot</a>
* <a title="Raider" href="CORRAID">Tech 1 Medium Assault Tank</a>
* <a title="Metal Maker" href="CORMAKR">Tech 1 Metal Maker</a>
* <a title="Spoiler" href="CORMLV">Tech 1 Mine Layer Vehicle</a>
* <a title="Crasher" href="CORCRASH">Tech 1 Missile Kbot</a>
* <a title="Pulverizer" href="CORRL">Tech 1 Missile Tower</a>
* <a title="Slasher" href="CORMIST">Tech 1 Mobile SAM Launcher</a>
* <a title="Dragons Teeth" href="CORDRAG">Tech 1 Perimeter Defence</a>
* <a title="Aircraft Plant" href="CORAP">Tech 1 Produces Aircraft</a>
* <a title="Geothermal Powerplant" href="CORGEO">Tech 1 Produces Energy</a>
* <a title="Tidal Generator" href="CORTIDE">Tech 1 Produces Energy</a>
* <a title="Kbot Lab" href="CORLAB">Tech 1 Produces Kbots</a>
* <a title="Shipyard" href="CORSY">Tech 1 Produces Ships</a>
* <a title="Vehicle Plant" href="CORVP">Tech 1 Produces Vehicles</a>
* <a title="Radar Tower" href="CORRAD">Tech 1 Radar Tower</a>
* <a title="Leveler" href="CORLEVLR">Tech 1 Riot Tank</a>
* <a title="Storm" href="CORSTORM">Tech 1 Rocket Kbot</a>
* <a title="Searcher" href="CORPT">Tech 1 Scout Ship</a>
* <a title="Weasel" href="CORFAV">Tech 1 Scout</a>
* <a title="Sonar Station" href="CORSONAR">Tech 1 Sonar Station</a>
* <a title="Snake" href="CORSUB">Tech 1 Submarine</a>
* <a title="Construction Aircraft" href="CORCA">Tech 1 Tech Level 1</a>
* <a title="Construction Kbot" href="CORCK">Tech 1 Tech Level 1</a>
* <a title="Construction Ship" href="CORCS">Tech 1 Tech Level 1</a>
* <a title="Construction Vehicle" href="CORCV">Tech 1 Tech Level 1</a>
* <a title="Torpedo Launcher" href="CORTL">Tech 1 Torpedo Launcher</a>
* <a title="Commander" href="CORCOM">Commander</a>
</p>
</details>

</td>
</tr>
</table>
</p>
</details>
</brewwikisidebar>