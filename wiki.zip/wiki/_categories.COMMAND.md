Units with the <code>COMMAND</code> category.
<table>
    <tr>
        <td><a href="ARMCOM"><img src="icons/units/ARMCOM_icon.png" width="21px" /></a></td>
        <td><code>armcom</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMCOM">Commander: Commander</a></td>
    </tr>
    <tr>
        <td><a href="CORCOM"><img src="icons/units/CORCOM_icon.png" width="21px" /></a></td>
        <td><code>corcom</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORCOM">Commander: Commander</a></td>
    </tr>
</table>
