Units with the <code>AEON</code> category.
<table>
    <tr>
        <td><a href="MSS0004"><img src="icons/units/MSS0004_icon.png" width="21px" /></a></td>
        <td><code>mss0004</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="MSS0004">Aeon Commander: Tech 1 Aeon</a></td>
    </tr>
</table>
