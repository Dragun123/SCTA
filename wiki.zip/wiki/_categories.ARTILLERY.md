Units with the <code>ARTILLERY</code> category.
<table>
    <tr>
        <td><a href="ARMHAM"><img src="icons/units/ARMHAM_icon.png" width="21px" /></a></td>
        <td><code>armham</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMHAM">Hammer: Tech 1 Artillery Kbot</a></td>
    </tr>
    <tr>
        <td><a href="CORLEVLR"><img src="icons/units/CORLEVLR_icon.png" width="21px" /></a></td>
        <td><code>corlevlr</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORLEVLR">Leveler: Tech 1 Riot Tank</a></td>
    </tr>
    <tr>
        <td><a href="CORTHUD"><img src="icons/units/CORTHUD_icon.png" width="21px" /></a></td>
        <td><code>corthud</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORTHUD">Thud: Tech 1 Artillery Kbot</a></td>
    </tr>
    <tr>
        <td><a href="ARMGUARD"><img src="icons/units/ARMGUARD_icon.png" width="21px" /></a></td>
        <td><code>armguard</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMGUARD">Guardian: Tech 2 Plasma Battery</a></td>
    </tr>
    <tr>
        <td><a href="ARMMART"><img src="icons/units/ARMMART_icon.png" width="21px" /></a></td>
        <td><code>armmart</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMMART">Luger: Tech 2 Mobile Artillery</a></td>
    </tr>
    <tr>
        <td><a href="CORMART"><img src="icons/units/CORMART_icon.png" width="21px" /></a></td>
        <td><code>cormart</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORMART">Pillager: Tech 2 Mobile Artillery</a></td>
    </tr>
    <tr>
        <td><a href="CORMORT"><img src="icons/units/CORMORT_icon.png" width="21px" /></a></td>
        <td><code>cormort</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORMORT">Morty: Tech 2 Mobile Mortar Kbot</a></td>
    </tr>
    <tr>
        <td><a href="CORPUN"><img src="icons/units/CORPUN_icon.png" width="21px" /></a></td>
        <td><code>corpun</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORPUN">Punisher: Tech 2 Plasma Battery</a></td>
    </tr>
    <tr>
        <td><a href="CORINT"><img src="icons/units/CORINT_icon.png" width="21px" /></a></td>
        <td><code>corint</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORINT">Intimidator: Tech 3 Long Range Plasma Cannon</a></td>
    </tr>
    <tr>
        <td><a href="ARMVULC"><img src="icons/units/ARMVULC_icon.png" width="21px" /></a></td>
        <td><code>armvulc</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMVULC">Vulcan: Rapid Fire Plasma Cannon</a></td>
    </tr>
    <tr>
        <td><a href="CORBUZZ"><img src="icons/units/CORBUZZ_icon.png" width="21px" /></a></td>
        <td><code>corbuzz</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORBUZZ">Buzzsaw: Rapid Fire Plasma Cannon</a></td>
    </tr>
</table>
