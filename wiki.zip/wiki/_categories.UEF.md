Units with the <code>UEF</code> category.
<table>
    <tr>
        <td><a href="MSS0003"><img src="icons/units/MSS0003_icon.png" width="21px" /></a></td>
        <td><code>mss0003</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="MSS0003">UEF Commander: Tech 1 UEF</a></td>
    </tr>
</table>
