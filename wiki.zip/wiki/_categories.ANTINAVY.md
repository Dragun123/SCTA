Units with the <code>ANTINAVY</code> category.
<table>
    <tr>
        <td><a href="ARMSUB"><img src="icons/units/ARMSUB_icon.png" width="21px" /></a></td>
        <td><code>armsub</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSUB">Lurker: Tech 1 Submarine</a></td>
    </tr>
    <tr>
        <td><a href="ARMTL"><img src="icons/units/ARMTL_icon.png" width="21px" /></a></td>
        <td><code>armtl</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMTL">Torpedo Launcher: Tech 1 Torpedo Launcher</a></td>
    </tr>
    <tr>
        <td><a href="CORSUB"><img src="icons/units/CORSUB_icon.png" width="21px" /></a></td>
        <td><code>corsub</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSUB">Snake: Tech 1 Submarine</a></td>
    </tr>
    <tr>
        <td><a href="CORTL"><img src="icons/units/CORTL_icon.png" width="21px" /></a></td>
        <td><code>cortl</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORTL">Torpedo Launcher: Tech 1 Torpedo Launcher</a></td>
    </tr>
    <tr>
        <td><a href="ARMATL"><img src="icons/units/ARMATL_icon.png" width="21px" /></a></td>
        <td><code>armatl</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMATL">Advanced Torpedo Launcher: Tech 2 Advanced Torpedo Launcher</a></td>
    </tr>
    <tr>
        <td><a href="ARMCRUS"><img src="icons/units/ARMCRUS_icon.png" width="21px" /></a></td>
        <td><code>armcrus</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMCRUS">Conqueror: Tech 2 Cruiser</a></td>
    </tr>
    <tr>
        <td><a href="ARMLANCE"><img src="icons/units/ARMLANCE_icon.png" width="21px" /></a></td>
        <td><code>armlance</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMLANCE">Lancet: Tech 2 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="ARMSUBK"><img src="icons/units/ARMSUBK_icon.png" width="21px" /></a></td>
        <td><code>armsubk</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSUBK">Pirahna: Tech 2 Submarine Killer </a></td>
    </tr>
    <tr>
        <td><a href="CORATL"><img src="icons/units/CORATL_icon.png" width="21px" /></a></td>
        <td><code>coratl</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORATL">Advanced Torpedo Launcher: Tech 2 Advanced Torpedo Launcher</a></td>
    </tr>
    <tr>
        <td><a href="CORSHARK"><img src="icons/units/CORSHARK_icon.png" width="21px" /></a></td>
        <td><code>corshark</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSHARK">Shark: Tech 2 Submarine Killer </a></td>
    </tr>
    <tr>
        <td><a href="CORSSUB"><img src="icons/units/CORSSUB_icon.png" width="21px" /></a></td>
        <td><code>corssub</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSSUB">Leviathen: Tech 2 Battle Submarine</a></td>
    </tr>
    <tr>
        <td><a href="CORTITAN"><img src="icons/units/CORTITAN_icon.png" width="21px" /></a></td>
        <td><code>cortitan</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORTITAN">Titan: Tech 2 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="ARMSEAP"><img src="icons/units/ARMSEAP_icon.png" width="21px" /></a></td>
        <td><code>armseap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSEAP">Albatross: Tech 3 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="CORSEAP"><img src="icons/units/CORSEAP_icon.png" width="21px" /></a></td>
        <td><code>corseap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSEAP">Typhoon: Tech 3 Torpedo Bomber</a></td>
    </tr>
</table>
