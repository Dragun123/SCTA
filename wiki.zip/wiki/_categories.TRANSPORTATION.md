Units with the <code>TRANSPORTATION</code> category.
<table>
    <tr>
        <td><a href="ARMATLAS"><img src="icons/units/ARMATLAS_icon.png" width="21px" /></a></td>
        <td><code>armatlas</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMATLAS">Atlas: Tech 1 Air Transport</a></td>
    </tr>
    <tr>
        <td><a href="CORVALK"><img src="icons/units/CORVALK_icon.png" width="21px" /></a></td>
        <td><code>corvalk</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORVALK">Valkyrie: Tech 1 Air Transport</a></td>
    </tr>
    <tr>
        <td><a href="ARMSEAP"><img src="icons/units/ARMSEAP_icon.png" width="21px" /></a></td>
        <td><code>armseap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSEAP">Albatross: Tech 3 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="ARMSEHAK"><img src="icons/units/ARMSEHAK_icon.png" width="21px" /></a></td>
        <td><code>armsehak</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSEHAK">Seahawk: Tech 3 Radar Plane</a></td>
    </tr>
    <tr>
        <td><a href="ARMSFIG"><img src="icons/units/ARMSFIG_icon.png" width="21px" /></a></td>
        <td><code>armsfig</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSFIG">Tornado: Tech 3 Seaplane Fighter</a></td>
    </tr>
    <tr>
        <td><a href="ARMTHOVR"><img src="icons/units/ARMTHOVR_icon.png" width="21px" /></a></td>
        <td><code>armthovr</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMTHOVR">Bear: Tech 3 Hover Transport</a></td>
    </tr>
    <tr>
        <td><a href="CORHUNT"><img src="icons/units/CORHUNT_icon.png" width="21px" /></a></td>
        <td><code>corhunt</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORHUNT">Hunter: Tech 3 Radar Plane</a></td>
    </tr>
    <tr>
        <td><a href="CORSEAP"><img src="icons/units/CORSEAP_icon.png" width="21px" /></a></td>
        <td><code>corseap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSEAP">Typhoon: Tech 3 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="CORSFIG"><img src="icons/units/CORSFIG_icon.png" width="21px" /></a></td>
        <td><code>corsfig</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSFIG">Voodoo: Tech 3 Seaplane Fighter</a></td>
    </tr>
    <tr>
        <td><a href="CORTHOVR"><img src="icons/units/CORTHOVR_icon.png" width="21px" /></a></td>
        <td><code>corthovr</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORTHOVR">Turtle: Tech 3 Hover Transport</a></td>
    </tr>
</table>
