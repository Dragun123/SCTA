Units with the <code>CYBRAN</code> category.
<table>
    <tr>
        <td><a href="MSS0002"><img src="icons/units/MSS0002_icon.png" width="21px" /></a></td>
        <td><code>mss0002</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="MSS0002">Cybran Commander: Tech 1 Cybran</a></td>
    </tr>
</table>
