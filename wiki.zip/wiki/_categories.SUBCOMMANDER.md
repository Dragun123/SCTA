Units with the <code>SUBCOMMANDER</code> category.
<table>
    <tr>
        <td><a href="ARMDECOM"><img src="icons/units/ARMDECOM_icon.png" width="21px" /></a></td>
        <td><code>armdecom</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMDECOM">Commander: Tech 2 Commander</a></td>
    </tr>
    <tr>
        <td><a href="CORDECOM"><img src="icons/units/CORDECOM_icon.png" width="21px" /></a></td>
        <td><code>cordecom</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORDECOM">Commander: Tech 2 Commander</a></td>
    </tr>
</table>
