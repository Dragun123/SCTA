Units with the <code>FIELDENGINEER</code> category.
<table>
    <tr>
        <td><a href="ARMMLV"><img src="icons/units/ARMMLV_icon.png" width="21px" /></a></td>
        <td><code>armmlv</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMMLV">Podger: Tech 1 Mine Layer Vehicle</a></td>
    </tr>
    <tr>
        <td><a href="CORMLV"><img src="icons/units/CORMLV_icon.png" width="21px" /></a></td>
        <td><code>cormlv</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORMLV">Spoiler: Tech 1 Mine Layer Vehicle</a></td>
    </tr>
    <tr>
        <td><a href="ARMFARK"><img src="icons/units/ARMFARK_icon.png" width="21px" /></a></td>
        <td><code>armfark</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMFARK">FARK: Tech 2 Fast Assist-Repair Kbot</a></td>
    </tr>
    <tr>
        <td><a href="CORNECRO"><img src="icons/units/CORNECRO_icon.png" width="21px" /></a></td>
        <td><code>cornecro</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORNECRO">Necro: Tech 2 Resurrection Kbot</a></td>
    </tr>
</table>
