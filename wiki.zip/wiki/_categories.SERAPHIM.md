Units with the <code>SERAPHIM</code> category.
<table>
    <tr>
        <td><a href="MSS0001"><img src="icons/units/MSS0001_icon.png" width="21px" /></a></td>
        <td><code>mss0001</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="MSS0001">Seraphim Commander: Tech 1 Seraphim</a></td>
    </tr>
</table>
