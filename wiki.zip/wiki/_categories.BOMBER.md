Units with the <code>BOMBER</code> category.
<table>
    <tr>
        <td><a href="ARMTHUND"><img src="icons/units/ARMTHUND_icon.png" width="21px" /></a></td>
        <td><code>armthund</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMTHUND">Thunder: Tech 1 Bomber</a></td>
    </tr>
    <tr>
        <td><a href="CORSHAD"><img src="icons/units/CORSHAD_icon.png" width="21px" /></a></td>
        <td><code>corshad</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSHAD">Shadow: Tech 1 Bomber</a></td>
    </tr>
    <tr>
        <td><a href="ARMLANCE"><img src="icons/units/ARMLANCE_icon.png" width="21px" /></a></td>
        <td><code>armlance</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMLANCE">Lancet: Tech 2 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="ARMPNIX"><img src="icons/units/ARMPNIX_icon.png" width="21px" /></a></td>
        <td><code>armpnix</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMPNIX">Pheonix: Tech 2 Strategic Bomber</a></td>
    </tr>
    <tr>
        <td><a href="CORHURC"><img src="icons/units/CORHURC_icon.png" width="21px" /></a></td>
        <td><code>corhurc</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORHURC">Hurricane: Tech 2 Strategic Bomber</a></td>
    </tr>
    <tr>
        <td><a href="CORTITAN"><img src="icons/units/CORTITAN_icon.png" width="21px" /></a></td>
        <td><code>cortitan</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORTITAN">Titan: Tech 2 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="ARMSEAP"><img src="icons/units/ARMSEAP_icon.png" width="21px" /></a></td>
        <td><code>armseap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMSEAP">Albatross: Tech 3 Torpedo Bomber</a></td>
    </tr>
    <tr>
        <td><a href="CORSEAP"><img src="icons/units/CORSEAP_icon.png" width="21px" /></a></td>
        <td><code>corseap</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORSEAP">Typhoon: Tech 3 Torpedo Bomber</a></td>
    </tr>
</table>
