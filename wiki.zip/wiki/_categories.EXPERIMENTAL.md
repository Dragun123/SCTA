Units with the <code>EXPERIMENTAL</code> category.
<table>
    <tr>
        <td><a href="ARMVULC"><img src="icons/units/ARMVULC_icon.png" width="21px" /></a></td>
        <td><code>armvulc</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="ARMVULC">Vulcan: Rapid Fire Plasma Cannon</a></td>
    </tr>
    <tr>
        <td><a href="CORBUZZ"><img src="icons/units/CORBUZZ_icon.png" width="21px" /></a></td>
        <td><code>corbuzz</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORBUZZ">Buzzsaw: Rapid Fire Plasma Cannon</a></td>
    </tr>
    <tr>
        <td><a href="CORGANT"><img src="icons/units/CORGANT_icon.png" width="21px" /></a></td>
        <td><code>corgant</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORGANT">Krogoth Gantry: Builds Krogoths</a></td>
    </tr>
    <tr>
        <td><a href="CORKROG"><img src="icons/units/CORKROG_icon.png" width="21px" /></a></td>
        <td><code>corkrog</code></td>
        <td><a href="SCTATest"><img src="icons/mods/sctatest.png" width="21px" /></a></td>
        <td><a href="CORKROG">Krogoth: Experimental Kbot</a></td>
    </tr>
</table>
